# Nutrition Search

Supabase `foods` 테이블을 검색하는 Next.js + Vercel용 프로젝트입니다.

## 필요한 환경변수

Vercel Environment Variables에 아래 값을 넣으세요.

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_or_publishable_key
```

## Supabase 테이블

기본 테이블명은 `foods`입니다.
검색 컬럼은 `FOOD_NM_KR`입니다.
